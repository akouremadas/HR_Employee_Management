﻿namespace HR_EMPL
{
    partial class SimpleUser
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.personaldatabtn = new System.Windows.Forms.Button();
            this.financialdatabtn = new System.Windows.Forms.Button();
            this.annualleavebtn = new System.Windows.Forms.Button();
            this.submitannualleavebtn = new System.Windows.Forms.Button();
            this.sendemailbtn = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // personaldatabtn
            // 
            this.personaldatabtn.Location = new System.Drawing.Point(6, 19);
            this.personaldatabtn.Name = "personaldatabtn";
            this.personaldatabtn.Size = new System.Drawing.Size(226, 23);
            this.personaldatabtn.TabIndex = 0;
            this.personaldatabtn.Text = "ΠΡΟΣΩΠΙΚΑ ΣΤΟΙΧΕΙΑ ΕΡΓΑΖΟΜΕΝΟΥ";
            this.personaldatabtn.UseVisualStyleBackColor = true;
            this.personaldatabtn.Click += new System.EventHandler(this.personaldatabtn_Click);
            // 
            // financialdatabtn
            // 
            this.financialdatabtn.Location = new System.Drawing.Point(6, 62);
            this.financialdatabtn.Name = "financialdatabtn";
            this.financialdatabtn.Size = new System.Drawing.Size(226, 23);
            this.financialdatabtn.TabIndex = 1;
            this.financialdatabtn.Text = "ΜΙΣΘΟΛΟΓΙΚΑ ΣΤΟΙΧΕΙΑ ΕΡΓΑΖΟΜΕΝΟΥ";
            this.financialdatabtn.UseVisualStyleBackColor = true;
            this.financialdatabtn.Click += new System.EventHandler(this.financialdatabtn_Click);
            // 
            // annualleavebtn
            // 
            this.annualleavebtn.Location = new System.Drawing.Point(6, 106);
            this.annualleavebtn.Name = "annualleavebtn";
            this.annualleavebtn.Size = new System.Drawing.Size(226, 23);
            this.annualleavebtn.TabIndex = 2;
            this.annualleavebtn.Text = "ΕΛΕΓΧΟΣ ΑΔΕΙΩΝ ΕΡΓΑΖΟΜΕΝΟΥ";
            this.annualleavebtn.UseVisualStyleBackColor = true;
            this.annualleavebtn.Click += new System.EventHandler(this.annualleavebtn_Click);
            // 
            // submitannualleavebtn
            // 
            this.submitannualleavebtn.Location = new System.Drawing.Point(6, 157);
            this.submitannualleavebtn.Name = "submitannualleavebtn";
            this.submitannualleavebtn.Size = new System.Drawing.Size(226, 23);
            this.submitannualleavebtn.TabIndex = 3;
            this.submitannualleavebtn.Text = "ΚΑΤΑΧΩΡΗΣΗ ΑΔΕΙΑΣ ΧΡΗΣΤΗ";
            this.submitannualleavebtn.UseVisualStyleBackColor = true;
            this.submitannualleavebtn.Click += new System.EventHandler(this.submitannualleavebtn_Click);
            // 
            // sendemailbtn
            // 
            this.sendemailbtn.Location = new System.Drawing.Point(6, 204);
            this.sendemailbtn.Name = "sendemailbtn";
            this.sendemailbtn.Size = new System.Drawing.Size(226, 23);
            this.sendemailbtn.TabIndex = 4;
            this.sendemailbtn.Text = "ΑΠΟΣΤΟΛΗ EMAIL ΠΡΟΣ HR";
            this.sendemailbtn.UseVisualStyleBackColor = true;
            this.sendemailbtn.Click += new System.EventHandler(this.sendemailbtn_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.personaldatabtn);
            this.groupBox1.Controls.Add(this.annualleavebtn);
            this.groupBox1.Controls.Add(this.submitannualleavebtn);
            this.groupBox1.Controls.Add(this.financialdatabtn);
            this.groupBox1.Controls.Add(this.sendemailbtn);
            this.groupBox1.Location = new System.Drawing.Point(4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(236, 249);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(246, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1335, 769);
            this.panel1.TabIndex = 7;
            // 
            // SimpleUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox1);
            this.Name = "SimpleUser";
            this.Size = new System.Drawing.Size(1584, 776);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button personaldatabtn;
        private System.Windows.Forms.Button financialdatabtn;
        private System.Windows.Forms.Button annualleavebtn;
        private System.Windows.Forms.Button submitannualleavebtn;
        private System.Windows.Forms.Button sendemailbtn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel1;
    }
}
