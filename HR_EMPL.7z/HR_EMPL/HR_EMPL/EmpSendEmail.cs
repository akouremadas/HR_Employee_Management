﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR_EMPL
{
    public partial class EmpSendEmail : UserControl
    {
        //singleton user control
        private static EmpSendEmail _instance;
        public static EmpSendEmail Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new EmpSendEmail();
                }
                return _instance;
            }
        }
        public EmpSendEmail()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Το μήνυμά σας στάλθηκε!");

            bodybox.Clear();            
        }
    }
}
