﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR_EMPL
{
    public partial class EmpContrTerm : UserControl
    {
        db db2 = new db();
        int emp_id;

        //singleton user control
        private static EmpContrTerm _instance;
        public static EmpContrTerm Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new EmpContrTerm();
                }
                return _instance;
            }
        }
        public EmpContrTerm()
        {
            InitializeComponent();
        }

        private void updatebtn_Click(object sender, EventArgs e)
        {
            try
            {
                emp_id = Int32.Parse(idbox.Text);
            }
            catch (FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }

            db2.db_open();

            db2.terminate_contract(emp_id, termpicker.Value, termcombobox.Text);

            db2.db_close();
        }
    }
}
