﻿namespace HR_EMPL
{
    partial class EmpRegAnnLeave
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label12 = new System.Windows.Forms.Label();
            this.idbox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.createbtn = new System.Windows.Forms.Button();
            this.startdate = new System.Windows.Forms.DateTimePicker();
            this.enddate = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.countlbl = new System.Windows.Forms.Label();
            this.restlbl = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(71, 87);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(87, 13);
            this.label12.TabIndex = 94;
            this.label12.Text = "ΕΝΑΡΞΗ ΑΔΕΙΑΣ";
            // 
            // idbox
            // 
            this.idbox.Location = new System.Drawing.Point(228, 39);
            this.idbox.Name = "idbox";
            this.idbox.Size = new System.Drawing.Size(200, 20);
            this.idbox.TabIndex = 92;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(70, 131);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 13);
            this.label8.TabIndex = 91;
            this.label8.Text = "ΛΗΞΗ ΑΔΕΙΑΣ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(71, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 13);
            this.label2.TabIndex = 90;
            this.label2.Text = "ΑΜ ΕΡΓΑΖΟΜΕΝΟΥ";
            // 
            // createbtn
            // 
            this.createbtn.Location = new System.Drawing.Point(87, 227);
            this.createbtn.Name = "createbtn";
            this.createbtn.Size = new System.Drawing.Size(299, 23);
            this.createbtn.TabIndex = 96;
            this.createbtn.Text = "ΥΠΟΒΟΛΗ ΑΙΤΗΜΑΤΟΣ ΚΑΝΟΝΙΚΗΣ ΑΔΕΙΑΣ";
            this.createbtn.UseVisualStyleBackColor = true;
            this.createbtn.Click += new System.EventHandler(this.createbtn_Click);
            // 
            // startdate
            // 
            this.startdate.Location = new System.Drawing.Point(228, 79);
            this.startdate.Name = "startdate";
            this.startdate.Size = new System.Drawing.Size(200, 20);
            this.startdate.TabIndex = 97;
            // 
            // enddate
            // 
            this.enddate.Location = new System.Drawing.Point(228, 125);
            this.enddate.Name = "enddate";
            this.enddate.Size = new System.Drawing.Size(200, 20);
            this.enddate.TabIndex = 99;
            this.enddate.ValueChanged += new System.EventHandler(this.enddate_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(70, 168);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 13);
            this.label1.TabIndex = 100;
            this.label1.Text = "ΕΡΓΑΣΙΜΕΣ ΜΕΡΕΣ";
            // 
            // countlbl
            // 
            this.countlbl.AutoSize = true;
            this.countlbl.Location = new System.Drawing.Point(225, 168);
            this.countlbl.Name = "countlbl";
            this.countlbl.Size = new System.Drawing.Size(10, 13);
            this.countlbl.TabIndex = 101;
            this.countlbl.Text = "-";
            // 
            // restlbl
            // 
            this.restlbl.AutoSize = true;
            this.restlbl.Location = new System.Drawing.Point(226, 201);
            this.restlbl.Name = "restlbl";
            this.restlbl.Size = new System.Drawing.Size(10, 13);
            this.restlbl.TabIndex = 103;
            this.restlbl.Text = "-";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(71, 201);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(135, 13);
            this.label4.TabIndex = 102;
            this.label4.Text = "ΥΠΟΛΟΙΠΟ ΑΔΕΙΑΣ ΕΤΟΥΣ";
            // 
            // EmpRegAnnLeave
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.restlbl);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.countlbl);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.enddate);
            this.Controls.Add(this.startdate);
            this.Controls.Add(this.createbtn);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.idbox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label2);
            this.Name = "EmpRegAnnLeave";
            this.Size = new System.Drawing.Size(496, 290);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox idbox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button createbtn;
        private System.Windows.Forms.DateTimePicker startdate;
        private System.Windows.Forms.DateTimePicker enddate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label countlbl;
        private System.Windows.Forms.Label restlbl;
        private System.Windows.Forms.Label label4;
    }
}
