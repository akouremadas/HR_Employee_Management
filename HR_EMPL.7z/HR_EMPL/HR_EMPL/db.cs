﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HR_EMPL
{
    class db
    {
        OleDbConnection conn;
        string connectionstring = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source=hr_db.accdb";


        public void db_open()//ok
        {
            conn = new OleDbConnection(connectionstring);

            try
            {
                conn.Open();
            }

            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
        }

        public void db_close()//ok
        {
            try
            {

                conn.Close();
            }

            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
        }



        public void create_user (string name, string surname, string birth, string gender, int age, string afm, string id, string ama, string amka, string address, string  land, string mobile, string email)
        {
            try
            {

                string myquery = "INSERT INTO emp_pd (emp_name,emp_surname,emp_bdate,emp_age,emp_gender,emp_afm,emp_id,emp_ama,emp_amka,emp_address,emp_landline,emp_mobile,emp_email) VALUES('"+name+"','"+surname+"','" + birth + "',"+age+",'"+gender+"','" + afm +"','"+id+"','"+ama+"','" + amka +"', '"+ address+"', '"+land+"','"+mobile+"','"+ email+"')";

                OleDbCommand cmd = new OleDbCommand(myquery, conn);
                cmd.ExecuteNonQuery();

                System.Windows.Forms.MessageBox.Show("Η καρτέλα εργαζομένου δημιουργήθηκε επιτυχώς!");

            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
        }//ok

        public void create_user_financial(int emp_id, int sal, float tax, int sal_after, string hiredate, string contr_type, int contr_dur, int pre_exp, int annual_leaves_nom)//ok
        {
            try
            {

                String myquery = "INSERT INTO emp_fd (emp_id,emp_sal,emp_tax,emp_sal_after,emp_hire_date,emp_contr_type,emp_contr_dur,emp_contr_term_date,emp_term_type,emp_pr-exp,emp_annual_leaves_nom) VALUES("+emp_id+","+sal+","+tax+","+sal_after+",'"+hiredate+"','"+contr_type+"',"+contr_dur+ ",'NULL','NULL'," + pre_exp+","+annual_leaves_nom+")";

                OleDbCommand cmd = new OleDbCommand(myquery, conn);
                cmd.ExecuteNonQuery();

                System.Windows.Forms.MessageBox.Show("Η καρτέλα εργαζομένου ενημερώθηκε επιτυχώς!");

            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
        }

        public void create_credentials(int emp_id, string username, string password, string role)//ok
        {
            try
            {
                
                String myquery = "INSERT INTO users (emp_id, emp_user, emp_pass, emp_role) VALUES("+emp_id +",'" + username +"','" + password + "','" + role +"')";

                OleDbCommand cmd = new OleDbCommand(myquery, conn);
                cmd.ExecuteNonQuery();

                System.Windows.Forms.MessageBox.Show("Τα στοιχεία εισόδου του εργαζομένου καταχωρήθηκαν επιτυχώς!");

            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
        }

        public string find_user(string username)//ok
        {
            try
            {

                String myquery = "SELECT emp_user, emp_pass ,  emp_role FROM users WHERE emp_user = '"+ username + "'";

                OleDbCommand cmd = new OleDbCommand(myquery, conn);

                OleDbDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    if (rdr.HasRows == true)
                    {
                        return rdr.GetString(0);
                    }
                    else
                    {
                        return null;
                    }
                }

                rdr.Close();

            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            return null;
        }

        public void change_credentials(string username, string password, string role)//ok
        {
            try
            {

                if ((password != null) && (role != null))
                {
                    String myquery = "UPDATE users SET emp_role = '" + role + "' , emp_pass = '" + password + "' WHERE emp_user = '" + username + "'";
                    OleDbCommand cmd = new OleDbCommand(myquery, conn);
                    cmd.ExecuteNonQuery();

                    System.Windows.Forms.MessageBox.Show("Η αλλαγή έγινε επιτυχώς");

                }
                else if (role != null)
                {
                    String myquery = "UPDATE users SET emp_role = '" + role + "' WHERE emp_user = '" + username + "'";
                    OleDbCommand cmd = new OleDbCommand(myquery, conn);
                    cmd.ExecuteNonQuery();

                    System.Windows.Forms.MessageBox.Show("Η αλλαγή έγινε επιτυχώς");
                }
                else
                {
                    String myquery = "UPDATE users SET emp_pass = '" + password + "' WHERE emp_user = '" + username + "'";
                    OleDbCommand cmd = new OleDbCommand(myquery, conn);
                    cmd.ExecuteNonQuery();

                    System.Windows.Forms.MessageBox.Show("Η αλλαγή έγινε επιτυχώς");
                }

                

            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
        }

        public string show_user_credentials(string emp_id)//ok
        {
            try
            {

                String myquery = "SELECT emp_user, emp_pass FROM users WHERE emp_id="+emp_id+"";
                OleDbCommand cmd = new OleDbCommand(myquery, conn);

                OleDbDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    if (rdr.HasRows == true)
                    {
                        return rdr.GetString(0);
                    }
                    else
                    {
                        return null;
                    }
                }

                rdr.Close();

            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            return null;
        }

        public int show_emp_id(string afm) //ok
        {
            try
            {

                String myquery = "SELECT ID FROM emp_pd WHERE emp_afm = '"+ afm +"'";
                OleDbCommand cmd = new OleDbCommand(myquery, conn);

                OleDbDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    if (rdr.HasRows == true)
                    {
                        return rdr.GetInt32(0);
                    }
                    else
                    {
                        return 0;
                    }
                }

                rdr.Close();

            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            return 0;
        }

        public void register_annual(int emp_id, string leave_start, string leave_end, int wdays, string month, int year, int rest)//ok
        {
            try
            {

                String myquery = "INSERT INTO emp_annual_leaves (ID,emp_id,leave_start,leave_wdays,leave_month_leave_year,leave_appr,leave_rest_days) VALUES('" +  emp_id +"',"+leave_start+ "," +wdays+ "," +leave_end+",'" + month +"',"+ year + ",'NO'," + rest+")";

                OleDbCommand cmd = new OleDbCommand(myquery, conn);
                cmd.ExecuteNonQuery();

                System.Windows.Forms.MessageBox.Show("Το αίτημά σας για κανονική άδεια υποβλήθηκε στο Τμήμα Προσωπικού επιτυχώς!");

            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
        }

        public string show_annual_for_approval()//ok
        {
            try
            {

                String myquery = "SELECT emp_name.emp.pd AS Όνομα, emp_surname.emp.pd AS Επώνυμο, *.emp_annual_leaves FROM emp_pd, emp_annual_leaves WHERE (id.emp_pd = emp_id.emp_annual_leaves) AND (leave_appr.emp_annual_leaves = 'NO')";
                OleDbCommand cmd = new OleDbCommand(myquery, conn);

                OleDbDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    if (rdr.HasRows == true)
                    {
                        return rdr.GetString(0);
                    }
                    else
                    {
                        return null;
                    }
                }

                rdr.Close();

            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            return null;
        }

        public void approve_annual(int emp_id, string approve)//ok
        {
            try
            {
                String myquery = "UPDATE emp_annual_leaves SET leave_appr = 'YES' WHERE (emp_id = "+emp_id+") AND (leave_appr = 'NO') ";

                OleDbCommand cmd = new OleDbCommand(myquery, conn);
                cmd.ExecuteNonQuery();

                System.Windows.Forms.MessageBox.Show("Η αλλαγή καταχωρήθηκε επιτυχώς!");

            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
        }

        public string show_year_annual()
        {
            try
            {

                String myquery = "SELECT FROM WHERE";
                OleDbCommand cmd = new OleDbCommand(myquery, conn);

                OleDbDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    if (rdr.HasRows == true)
                    {
                        return rdr.GetString(0);
                    }
                    else
                    {
                        return null;
                    }
                }

                rdr.Close();

            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            return null;
        }

        public void terminate_contract(int emp_id, DateTime term_date, string term_type)//ok
        {
            try
            {

                String myquery = "UPDATE emp_fd SET emp_contr_term_date = "+term_date+", emp_term_type = '"+term_type+"' WHERE emp_id = "+emp_id+"";

                String myquery1 = "UPDATE users SET emp_pass = 'no_user' WHERE emp_id = " + emp_id + "";

                OleDbCommand cmd = new OleDbCommand(myquery, conn);
                cmd.ExecuteNonQuery();

                OleDbCommand cmd1 = new OleDbCommand(myquery1, conn);
                cmd1.ExecuteNonQuery();

                System.Windows.Forms.MessageBox.Show("Η αλλαγή καταχωρήθηκε επιτυχώς!");

            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
        }

        public string show_user_pd(int emp_id)//ok
        {
            try
            {

                String myquery = "SELECT * FROM emp_pd WHERE ID = '+emp_id+'";
                OleDbCommand cmd = new OleDbCommand(myquery, conn);

                cmd.ExecuteNonQuery();

                OleDbDataReader rdr = cmd.ExecuteReader();

                DataTable dt = new DataTable();
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);

                da.Fill(dt);

                

                while (rdr.Read())
                {
                    if (rdr.HasRows == true)
                    {
                        return rdr.GetString(0);
                    }
                    else
                    {
                        return null;
                    }
                }

                rdr.Close();

            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            return null;
        }

        public string show_user_fd(string emp_id)//ok
        {
            try
            {

                String myquery = "SELECT * FROM emp_fd WHERE emp_id = '+emp_id+'";
                OleDbCommand cmd = new OleDbCommand(myquery, conn);

                OleDbDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    if (rdr.HasRows == true)
                    {
                        return rdr.GetString(0);
                    }
                    else
                    {
                        return null;
                    }
                }

                rdr.Close();

            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            return null;
        }

        public string show_user_annual_leaves()
        {
            try
            {

                String myquery = "SELECT FROM WHERE";
                OleDbCommand cmd = new OleDbCommand(myquery, conn);

                OleDbDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    if (rdr.HasRows == true)
                    {
                        return rdr.GetString(0);
                    }
                    else
                    {
                        return null;
                    }
                }

                rdr.Close();

            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            return null;
        }

        public void db_user_auth(string u, string p)//ok
        {
            try
            {
                String myquery = "SELECT emp_user FROM users WHERE (emp_user ='" + u + "') AND (emp_pass ='" + p + "')";
                String myquery2 = "SELECT emp_pass FROM users WHERE (emp_user ='" + u + "') AND (emp_pass ='" + p + "')";
                OleDbCommand cmd = new OleDbCommand(myquery, conn);
                OleDbCommand cmd2 = new OleDbCommand(myquery2, conn);
                OleDbDataReader rdr = cmd.ExecuteReader();
                OleDbDataReader rdr2 = cmd2.ExecuteReader();
                if (rdr.HasRows == true)
                {
                    if (rdr2.HasRows == true)
                    {
                        System.Windows.Forms.MessageBox.Show("Επιτυχής είσοδος στην εφαρμογή!");
                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Ο κωδικός χρήστη είναι λάθος. Παρακαλώ δοκιμάστε ξανά.");
                    }

                }
                else
                {
                    System.Windows.Forms.MessageBox.Show(" Το όνομα χρήστη είναι λάθος. Παρακαλώ δοκιμάστε ξανά.");
                }

                rdr.Close();
                rdr2.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            

        }

        public string user_retrieve_role(string u)//ok
        {
            try
            {
                String myquery = "SELECT emp_role FROM users WHERE emp_user ='" + u + "'";
                OleDbCommand cmd = new OleDbCommand(myquery, conn);
                OleDbDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    if (rdr.HasRows == true)
                    {
                        return rdr.GetString(0);
                    }
                    else
                    {
                        return null;
                    }
                }

                rdr.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            return null;
        }

        public int user_retrieve_id(string u)//ok
        {
            try
            {
                String myquery = "SELECT emp_id FROM users WHERE emp_user ='" + u + "'";
                OleDbCommand cmd = new OleDbCommand(myquery, conn);
                OleDbDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    if (rdr.HasRows == true)
                    {
                        return rdr.GetInt32(0);
                    }
                    else
                    {
                        return 0;
                    }
                }

                rdr.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            return 0;
        }

    }
}
