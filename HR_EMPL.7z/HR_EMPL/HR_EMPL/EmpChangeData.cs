﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR_EMPL
{
    public partial class EmpChangeData : UserControl
    {
        db db4 = new db();

        //singleton user control
        private static EmpChangeData _instance;
        public static EmpChangeData Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new EmpChangeData();
                }
                return _instance;
            }
        }
        public EmpChangeData()
        {
            InitializeComponent();
        }

        private void createbtn_Click(object sender, EventArgs e)
        {
            db4.db_open();

            db4.update_user_data(int emp_id, string address, int land, int mobile, string email);

            db4.db_close();
        }
    }
}
