﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR_EMPL
{
    public partial class EmpChangeAnnLeave : UserControl
    {
        //singleton user control
        private static EmpChangeAnnLeave _instance;
        public static EmpChangeAnnLeave Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new EmpChangeAnnLeave();
                }
                return _instance;
            }
        }
        public EmpChangeAnnLeave()
        {
            InitializeComponent();
        }
    }
}
