﻿namespace HR_EMPL
{
    partial class EmpFinData
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.normleavesbox = new System.Windows.Forms.TextBox();
            this.prexpbox = new System.Windows.Forms.TextBox();
            this.contrdurbox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.clearbox = new System.Windows.Forms.TextBox();
            this.kratiseisbox = new System.Windows.Forms.TextBox();
            this.salarybox = new System.Windows.Forms.TextBox();
            this.idbox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.hiredateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.updatebtn = new System.Windows.Forms.Button();
            this.contractcomboBox = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // normleavesbox
            // 
            this.normleavesbox.Location = new System.Drawing.Point(236, 403);
            this.normleavesbox.Name = "normleavesbox";
            this.normleavesbox.Size = new System.Drawing.Size(180, 20);
            this.normleavesbox.TabIndex = 43;
            this.normleavesbox.TextChanged += new System.EventHandler(this.normleavesbox_TextChanged);
            // 
            // prexpbox
            // 
            this.prexpbox.Location = new System.Drawing.Point(216, 354);
            this.prexpbox.Name = "prexpbox";
            this.prexpbox.Size = new System.Drawing.Size(200, 20);
            this.prexpbox.TabIndex = 42;
            // 
            // contrdurbox
            // 
            this.contrdurbox.Location = new System.Drawing.Point(216, 307);
            this.contrdurbox.Name = "contrdurbox";
            this.contrdurbox.Size = new System.Drawing.Size(200, 20);
            this.contrdurbox.TabIndex = 40;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(56, 406);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(174, 13);
            this.label11.TabIndex = 39;
            this.label11.Text = "ΕΤΗΣΙΟ ΣΥΝΟΛΟ ΗΜΕΡΩΝ ΑΔΕΙΑΣ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(56, 357);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(106, 13);
            this.label10.TabIndex = 38;
            this.label10.Text = "ΠΡΟΫΠΗΡΕΣΙΑ (ΕΤΗ)";
            // 
            // clearbox
            // 
            this.clearbox.Location = new System.Drawing.Point(216, 164);
            this.clearbox.Name = "clearbox";
            this.clearbox.Size = new System.Drawing.Size(200, 20);
            this.clearbox.TabIndex = 33;
            this.clearbox.TextChanged += new System.EventHandler(this.clearbox_TextChanged);
            // 
            // kratiseisbox
            // 
            this.kratiseisbox.Location = new System.Drawing.Point(216, 122);
            this.kratiseisbox.Name = "kratiseisbox";
            this.kratiseisbox.Size = new System.Drawing.Size(200, 20);
            this.kratiseisbox.TabIndex = 32;
            this.kratiseisbox.TextChanged += new System.EventHandler(this.kratiseisbox_TextChanged);
            // 
            // salarybox
            // 
            this.salarybox.Location = new System.Drawing.Point(216, 84);
            this.salarybox.Name = "salarybox";
            this.salarybox.Size = new System.Drawing.Size(200, 20);
            this.salarybox.TabIndex = 31;
            // 
            // idbox
            // 
            this.idbox.Location = new System.Drawing.Point(216, 35);
            this.idbox.Name = "idbox";
            this.idbox.Size = new System.Drawing.Size(200, 20);
            this.idbox.TabIndex = 30;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(56, 310);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(155, 13);
            this.label8.TabIndex = 29;
            this.label8.Text = "ΔΙΑΡΚΕΙΑ ΣΥΜΒΑΣΗΣ (ΜΗΝΕΣ)";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(56, 260);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(102, 13);
            this.label7.TabIndex = 28;
            this.label7.Text = "ΤΥΠΟΣ ΣΥΜΒΑΣΗΣ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(56, 210);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(140, 13);
            this.label6.TabIndex = 27;
            this.label6.Text = "ΗΜΕΡΟΜΗΝΙΑ ΠΡΟΣΛΗΨΗΣ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(58, 167);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(112, 13);
            this.label5.TabIndex = 26;
            this.label5.Text = "ΚΑΘΑΡΕΣ ΑΠΟΔΟΧΕΣ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(56, 125);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 13);
            this.label4.TabIndex = 25;
            this.label4.Text = "ΚΡΑΤΗΣΕΙΣ %";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(56, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 13);
            this.label2.TabIndex = 23;
            this.label2.Text = "ΜΕΙΚΤΕΣ ΑΠΟΔΟΧΕΣ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(56, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 13);
            this.label1.TabIndex = 22;
            this.label1.Text = "ΑΜ ΕΡΓΑΖΟΜΕΝΟΥ";
            // 
            // hiredateTimePicker
            // 
            this.hiredateTimePicker.Location = new System.Drawing.Point(216, 204);
            this.hiredateTimePicker.Name = "hiredateTimePicker";
            this.hiredateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.hiredateTimePicker.TabIndex = 44;
            // 
            // updatebtn
            // 
            this.updatebtn.Location = new System.Drawing.Point(59, 460);
            this.updatebtn.Name = "updatebtn";
            this.updatebtn.Size = new System.Drawing.Size(315, 23);
            this.updatebtn.TabIndex = 54;
            this.updatebtn.Text = "ΕΝΗΜΕΡΩΣΗ ΚΑΡΤΕΛΑΣ ΕΡΓΑΖΟΜΕΝΟΥ";
            this.updatebtn.UseVisualStyleBackColor = true;
            this.updatebtn.Click += new System.EventHandler(this.updatebtn_Click);
            // 
            // contractcomboBox
            // 
            this.contractcomboBox.FormattingEnabled = true;
            this.contractcomboBox.Items.AddRange(new object[] {
            "FULL TIME",
            "PART TIME"});
            this.contractcomboBox.Location = new System.Drawing.Point(216, 257);
            this.contractcomboBox.Name = "contractcomboBox";
            this.contractcomboBox.Size = new System.Drawing.Size(200, 21);
            this.contractcomboBox.TabIndex = 55;
            // 
            // EmpFinData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.contractcomboBox);
            this.Controls.Add(this.updatebtn);
            this.Controls.Add(this.hiredateTimePicker);
            this.Controls.Add(this.normleavesbox);
            this.Controls.Add(this.prexpbox);
            this.Controls.Add(this.contrdurbox);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.clearbox);
            this.Controls.Add(this.kratiseisbox);
            this.Controls.Add(this.salarybox);
            this.Controls.Add(this.idbox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "EmpFinData";
            this.Size = new System.Drawing.Size(498, 505);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox normleavesbox;
        private System.Windows.Forms.TextBox prexpbox;
        private System.Windows.Forms.TextBox contrdurbox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox clearbox;
        private System.Windows.Forms.TextBox kratiseisbox;
        private System.Windows.Forms.TextBox salarybox;
        private System.Windows.Forms.TextBox idbox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker hiredateTimePicker;
        private System.Windows.Forms.Button updatebtn;
        private System.Windows.Forms.ComboBox contractcomboBox;
    }
}
