﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR_EMPL
{
    public partial class EmpShowTargets : UserControl
    {
        //singleton user control
        private static EmpShowTargets _instance;
        public static EmpShowTargets Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new EmpShowTargets();
                }
                return _instance;
            }
        }
        public EmpShowTargets()
        {
            InitializeComponent();
        }
    }
}
