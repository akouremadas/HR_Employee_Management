﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace HR_EMPL
{
    public partial class EmpAnnualLeaveApproval : UserControl
    {
        OleDbConnection conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0; Data Source=hr_db.accdb");

        //singleton user control
        private static EmpAnnualLeaveApproval _instance;
        private int id1;

        public static EmpAnnualLeaveApproval Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new EmpAnnualLeaveApproval();
                }
                return _instance;
            }
        }
        public EmpAnnualLeaveApproval()
        {
            InitializeComponent();
            show_annual_for_approval();
        }

        public void show_annual_for_approval()
        {
            conn.Open();
            String myquery = "SELECT emp_pd.emp_name AS ONOMA, emp_pd.emp_surname AS ΕΠΩΝΥΜΟ, emp_annual_leaves.* FROM emp_pd INNER JOIN emp_annual_leaves ON emp_pd.id = emp_annual_leaves.emp_id WHERE emp_annual_leaves.leave_appr = 'NO'";
            OleDbCommand cmd = new OleDbCommand(myquery, conn);

            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);

            da.Fill(dt);

            dataGridView1.DataSource = dt;

            conn.Close();
        }

        private void approvebtn_Click(object sender, EventArgs e)
        {
            int i = dataGridView1.CurrentRow.Index;

            conn.Open();
            String myquery = "UPDATE emp_annual_leaves SET leave_appr = 'YES' WHERE (emp_id = " + dataGridView1.CurrentRow.Cells[3].Value + ") AND (leave_appr = 'NO')";
            OleDbCommand cmd = new OleDbCommand(myquery, conn);
            cmd.ExecuteNonQuery();
            conn.Close();

            //MessageBox.Show(i.ToString() + dataGridView1.CurrentRow.Cells[3].Value.ToString());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                conn.Open();
                String myquery = "UPDATE emp_annual_leaves SET leave_appr = 'YES' WHERE (emp_id = " + row.Cells[3].Value + ") AND (leave_appr = 'NO')";
                OleDbCommand cmd = new OleDbCommand(myquery, conn);
                cmd.ExecuteNonQuery();
                conn.Close();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            show_annual_for_approval();
        }
    }
}
