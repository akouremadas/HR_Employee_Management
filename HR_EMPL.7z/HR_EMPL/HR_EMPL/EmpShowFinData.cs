﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace HR_EMPL
{
    public partial class EmpShowFinData : UserControl
    {

        OleDbConnection conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0; Data Source=hr_db.accdb");

        //singleton user control
        private static EmpShowFinData _instance;
        public static EmpShowFinData Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new EmpShowFinData();
                }
                return _instance;
            }
        }
        public EmpShowFinData()
        {
            InitializeComponent();
            int id = Login.id;
            show_user_fd(id);
        }

        public void show_user_fd(int id)//ok
        {
            conn.Open();
            String myquery = "SELECT * FROM emp_fd WHERE emp_id = " + id + "";
            OleDbCommand cmd = new OleDbCommand(myquery, conn);

            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);

            da.Fill(dt);

            dataGridView1.DataSource = dt;

            conn.Close();
        }


    }
}
