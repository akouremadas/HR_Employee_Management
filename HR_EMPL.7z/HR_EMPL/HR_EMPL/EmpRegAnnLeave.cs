﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR_EMPL
{
    public partial class EmpRegAnnLeave : UserControl
    {
        db db2 = new db();
        int c, emp_id;
        DateTime a, b;

        //singleton user control
        private static EmpRegAnnLeave _instance;
        public static EmpRegAnnLeave Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new EmpRegAnnLeave();
                }
                return _instance;
            }
        }
        public EmpRegAnnLeave()
        {
            InitializeComponent();
        }

        private void createbtn_Click(object sender, EventArgs e)
        {

            try
            {
                emp_id = Int32.Parse(idbox.Text);                
            }
            catch (FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }

            db2.db_open();

            db2.register_annual(emp_id, startdate.Value.ToShortDateString(), enddate.Value.ToShortDateString(), c, b.Month.ToString(), b.Year, 22-c+1);

            db2.db_close();
        }

        private void enddate_ValueChanged(object sender, EventArgs e)
        {
            a = enddate.Value;
            b = startdate.Value;
            c = (a - b).Days;

            countlbl.Text = (c + 1).ToString();

            restlbl.Text = (22 - c + 1).ToString();
        }
    }
}
