﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR_EMPL
{
    public partial class EmpShowPersData : UserControl
    {

        OleDbConnection conn = new OleDbConnection ("Provider=Microsoft.ACE.OLEDB.12.0; Data Source=hr_db.accdb");

        //singleton user control
        private static EmpShowPersData _instance;
        public static EmpShowPersData Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new EmpShowPersData();
                }
                return _instance;
            }
        }
        public EmpShowPersData()
        {
            InitializeComponent();
            int id = Login.id;
            show_user_pd(id);
        }

        public void show_user_pd(int id)//ok
        {
            conn.Open();
            String myquery = "SELECT * FROM emp_pd WHERE ID = "+id+"";
            OleDbCommand cmd = new OleDbCommand(myquery, conn);

            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);

            da.Fill(dt);

            dataGridView1.DataSource = dt;

            conn.Close();
        }
    }
}
