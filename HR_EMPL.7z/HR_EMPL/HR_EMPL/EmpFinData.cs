﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR_EMPL
{
    public partial class EmpFinData : UserControl
    {
        db db3 = new db();
        int sal, tax, sal_after, contr_dur, pre_exp, annual_leaves_nom;

        

        private void normleavesbox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                pre_exp = Int32.Parse(prexpbox.Text);
            }
            catch (FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }
            if (pre_exp <= 1)
            {
                normleavesbox.Text = "20";
            }
            else if (pre_exp <= 12)
            {
                normleavesbox.Text = "22";
            }
            else
            {
                normleavesbox.Text = "25";
            }
        }

        private void clearbox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                sal = Int32.Parse(salarybox.Text);
                tax = Int32.Parse(kratiseisbox.Text);
            }
            catch (FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }

            double clear_sal = (sal * (1 - (tax * 0.01)));
            clearbox.Text = clear_sal.ToString();
        }

        private void kratiseisbox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                sal = Int32.Parse(salarybox.Text);
            }
            catch (FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }

            if (sal <= 700)
            {
                kratiseisbox.Text = "10";
            }
            else if (sal <= 1200)
            {
                kratiseisbox.Text = "16";
            }
            else
            {
                kratiseisbox.Text = "25";
            }
        }

        private static EmpFinData _instance;
       
        public static EmpFinData Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new EmpFinData();
                }
                return _instance;
            }
        }
        public EmpFinData()
        {
            InitializeComponent();
        }

        private void updatebtn_Click(object sender, EventArgs e)
        {

            try
            {
                sal = Int32.Parse(salarybox.Text.Split(null)[0]);
                tax = Int32.Parse(kratiseisbox.Text.Split(null)[0]);
                sal_after = Int32.Parse(clearbox.Text.Split(null)[0]);
                contr_dur = Int32.Parse(contrdurbox.Text);
                pre_exp = Int32.Parse(prexpbox.Text);
                annual_leaves_nom = Int32.Parse(normleavesbox.Text);
            }
            catch (FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }

            db3.db_open();

            db3.create_user_financial(EmpPersData.idnew, sal, tax, sal_after, hiredateTimePicker.Value.ToString(), contractcomboBox.Text, contr_dur, pre_exp, annual_leaves_nom);

            db3.db_close();
        }
    }
}
