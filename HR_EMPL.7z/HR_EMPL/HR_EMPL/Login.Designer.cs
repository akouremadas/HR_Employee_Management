﻿namespace HR_EMPL
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.loginpicbox = new System.Windows.Forms.PictureBox();
            this.cancelbtn = new System.Windows.Forms.Button();
            this.passtxtbox = new System.Windows.Forms.TextBox();
            this.enterbtn = new System.Windows.Forms.Button();
            this.usernametxtbox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.usernamelbl = new System.Windows.Forms.Label();
            this.passlbl = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.loginpicbox)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.loginpicbox);
            this.groupBox1.Controls.Add(this.cancelbtn);
            this.groupBox1.Controls.Add(this.passtxtbox);
            this.groupBox1.Controls.Add(this.enterbtn);
            this.groupBox1.Controls.Add(this.usernametxtbox);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.usernamelbl);
            this.groupBox1.Controls.Add(this.passlbl);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(617, 275);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            // 
            // loginpicbox
            // 
            this.loginpicbox.Image = ((System.Drawing.Image)(resources.GetObject("loginpicbox.Image")));
            this.loginpicbox.Location = new System.Drawing.Point(6, 34);
            this.loginpicbox.Name = "loginpicbox";
            this.loginpicbox.Size = new System.Drawing.Size(199, 196);
            this.loginpicbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.loginpicbox.TabIndex = 4;
            this.loginpicbox.TabStop = false;
            // 
            // cancelbtn
            // 
            this.cancelbtn.AutoSize = true;
            this.cancelbtn.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.cancelbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.cancelbtn.Location = new System.Drawing.Point(423, 214);
            this.cancelbtn.Name = "cancelbtn";
            this.cancelbtn.Size = new System.Drawing.Size(88, 28);
            this.cancelbtn.TabIndex = 3;
            this.cancelbtn.Text = "ΑΚΥΡΩΣΗ";
            this.cancelbtn.UseVisualStyleBackColor = true;
            this.cancelbtn.Click += new System.EventHandler(this.cancelbtn_Click);
            // 
            // passtxtbox
            // 
            this.passtxtbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.passtxtbox.Location = new System.Drawing.Point(367, 156);
            this.passtxtbox.Name = "passtxtbox";
            this.passtxtbox.PasswordChar = '*';
            this.passtxtbox.Size = new System.Drawing.Size(153, 24);
            this.passtxtbox.TabIndex = 1;
            this.passtxtbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.passtxtbox_KeyPress);
            // 
            // enterbtn
            // 
            this.enterbtn.AutoSize = true;
            this.enterbtn.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.enterbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.enterbtn.Location = new System.Drawing.Point(229, 214);
            this.enterbtn.Name = "enterbtn";
            this.enterbtn.Size = new System.Drawing.Size(82, 28);
            this.enterbtn.TabIndex = 2;
            this.enterbtn.Text = "ΕΙΣΟΔΟΣ";
            this.enterbtn.UseVisualStyleBackColor = true;
            this.enterbtn.Click += new System.EventHandler(this.enterbtn_Click);
            // 
            // usernametxtbox
            // 
            this.usernametxtbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.usernametxtbox.Location = new System.Drawing.Point(367, 98);
            this.usernametxtbox.Name = "usernametxtbox";
            this.usernametxtbox.Size = new System.Drawing.Size(153, 24);
            this.usernametxtbox.TabIndex = 0;
            this.usernametxtbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.usernametxtbox_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label1.Location = new System.Drawing.Point(211, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(375, 18);
            this.label1.TabIndex = 1;
            this.label1.Text = " ΠΑΡΑΚΑΛΩ ΕΙΣΑΓΕΤΕ ΟΝΟΜΑ ΚΑΙ ΚΩΔΙΚΟ ΧΡΗΣΤΗ";
            // 
            // usernamelbl
            // 
            this.usernamelbl.AutoSize = true;
            this.usernamelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.usernamelbl.Location = new System.Drawing.Point(211, 101);
            this.usernamelbl.Name = "usernamelbl";
            this.usernamelbl.Size = new System.Drawing.Size(133, 18);
            this.usernamelbl.TabIndex = 5;
            this.usernamelbl.Text = "ΟΝΟΜΑ ΧΡΗΣΤΗ:";
            // 
            // passlbl
            // 
            this.passlbl.AutoSize = true;
            this.passlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.passlbl.Location = new System.Drawing.Point(211, 159);
            this.passlbl.Name = "passlbl";
            this.passlbl.Size = new System.Drawing.Size(141, 18);
            this.passlbl.TabIndex = 4;
            this.passlbl.Text = "ΚΩΔΙΚΟΣ ΧΡΗΣΤΗ:";
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(654, 303);
            this.Controls.Add(this.groupBox1);
            this.Name = "Login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.loginpicbox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox loginpicbox;
        private System.Windows.Forms.Button cancelbtn;
        private System.Windows.Forms.TextBox passtxtbox;
        private System.Windows.Forms.Button enterbtn;
        private System.Windows.Forms.TextBox usernametxtbox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label usernamelbl;
        private System.Windows.Forms.Label passlbl;
    }
}