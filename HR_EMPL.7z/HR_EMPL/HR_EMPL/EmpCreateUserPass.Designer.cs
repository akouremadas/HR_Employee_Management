﻿namespace HR_EMPL
{
    partial class EmpCreateUserPass
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label4 = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.userbox = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.passbox = new System.Windows.Forms.TextBox();
            this.idbox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.rolecombo = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 195);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "ACCESS LEVEL";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // userbox
            // 
            this.userbox.Location = new System.Drawing.Point(17, 100);
            this.userbox.Name = "userbox";
            this.userbox.Size = new System.Drawing.Size(186, 20);
            this.userbox.TabIndex = 89;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(15, 79);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(68, 13);
            this.label12.TabIndex = 88;
            this.label12.Text = "USERNAME";
            // 
            // passbox
            // 
            this.passbox.Location = new System.Drawing.Point(17, 145);
            this.passbox.Name = "passbox";
            this.passbox.Size = new System.Drawing.Size(186, 20);
            this.passbox.TabIndex = 87;
            // 
            // idbox
            // 
            this.idbox.Location = new System.Drawing.Point(17, 37);
            this.idbox.Name = "idbox";
            this.idbox.Size = new System.Drawing.Size(186, 20);
            this.idbox.TabIndex = 86;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(14, 129);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(70, 13);
            this.label8.TabIndex = 85;
            this.label8.Text = "PASSWORD";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 13);
            this.label2.TabIndex = 84;
            this.label2.Text = "ΑΜ ΕΡΓΑΖΟΜΕΝΟΥ";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(17, 248);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 90;
            this.button1.Text = "ΥΠΟΒΟΛΗ";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // rolecombo
            // 
            this.rolecombo.FormattingEnabled = true;
            this.rolecombo.Items.AddRange(new object[] {
            "USER",
            "HR",
            "ADMIN"});
            this.rolecombo.Location = new System.Drawing.Point(17, 211);
            this.rolecombo.Name = "rolecombo";
            this.rolecombo.Size = new System.Drawing.Size(186, 21);
            this.rolecombo.TabIndex = 91;
            // 
            // EmpCreateUserPass
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.rolecombo);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.userbox);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.passbox);
            this.Controls.Add(this.idbox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Name = "EmpCreateUserPass";
            this.Size = new System.Drawing.Size(279, 395);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TextBox userbox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox passbox;
        private System.Windows.Forms.TextBox idbox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox rolecombo;
    }
}
