﻿namespace HR_EMPL
{
    partial class EmpChangeCred
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.rolecombo = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.userbox = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.passbox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 156);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 13);
            this.label4.TabIndex = 92;
            this.label4.Text = "ACCESS LEVEL";
            // 
            // rolecombo
            // 
            this.rolecombo.FormattingEnabled = true;
            this.rolecombo.Items.AddRange(new object[] {
            "Employee",
            "Employee-Manager",
            "HR",
            "Admin"});
            this.rolecombo.Location = new System.Drawing.Point(125, 153);
            this.rolecombo.Name = "rolecombo";
            this.rolecombo.Size = new System.Drawing.Size(186, 21);
            this.rolecombo.TabIndex = 100;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(163, 217);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(135, 23);
            this.button1.TabIndex = 99;
            this.button1.Text = "ΥΠΟΒΛΗ ΑΛΛΑΓΗΣ";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // userbox
            // 
            this.userbox.Location = new System.Drawing.Point(125, 37);
            this.userbox.Name = "userbox";
            this.userbox.Size = new System.Drawing.Size(186, 20);
            this.userbox.TabIndex = 98;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(25, 40);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(68, 13);
            this.label12.TabIndex = 97;
            this.label12.Text = "USERNAME";
            // 
            // passbox
            // 
            this.passbox.Location = new System.Drawing.Point(125, 87);
            this.passbox.Name = "passbox";
            this.passbox.Size = new System.Drawing.Size(186, 20);
            this.passbox.TabIndex = 96;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(24, 90);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(70, 13);
            this.label8.TabIndex = 94;
            this.label8.Text = "PASSWORD";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(27, 217);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 101;
            this.button2.Text = "ΕΥΡΕΣΗ";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // EmpChangeCred
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.rolecombo);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.userbox);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.passbox);
            this.Controls.Add(this.label8);
            this.Name = "EmpChangeCred";
            this.Size = new System.Drawing.Size(335, 313);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox rolecombo;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox userbox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox passbox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button2;
    }
}
