﻿namespace HR_EMPL
{
    partial class EmpShowAnnLeave
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.emp_annual_leavesDataGridView = new System.Windows.Forms.DataGridView();
            this.emp_annual_leavesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.emp_annual_leavesDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emp_annual_leavesBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // emp_annual_leavesDataGridView
            // 
            this.emp_annual_leavesDataGridView.AllowUserToAddRows = false;
            this.emp_annual_leavesDataGridView.AllowUserToDeleteRows = false;
            this.emp_annual_leavesDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.emp_annual_leavesDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9});
            this.emp_annual_leavesDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.emp_annual_leavesDataGridView.Location = new System.Drawing.Point(0, 0);
            this.emp_annual_leavesDataGridView.Name = "emp_annual_leavesDataGridView";
            this.emp_annual_leavesDataGridView.ReadOnly = true;
            this.emp_annual_leavesDataGridView.Size = new System.Drawing.Size(1335, 769);
            this.emp_annual_leavesDataGridView.TabIndex = 0;
            // 
            // ID
            // 
            this.ID.HeaderText = " ΑΑ";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "emp_id";
            this.dataGridViewTextBoxColumn2.HeaderText = "AM";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "leave_start";
            this.dataGridViewTextBoxColumn3.HeaderText = "ΕΝΑΡΞΗ ΑΔΕΙΑΣ";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "leave_end";
            this.dataGridViewTextBoxColumn4.HeaderText = "ΛΗΞΗ ΑΔΕΙΑΣ";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "leave_wdays";
            this.dataGridViewTextBoxColumn5.HeaderText = "ΕΡΓΑΣΙΜΕΣ ΜΕΡΕΣ";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "leave_year";
            this.dataGridViewTextBoxColumn7.HeaderText = "ΕΤΟΣ ΑΔΕΙΑΣ";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "leave_appr";
            this.dataGridViewTextBoxColumn8.HeaderText = "ΕΓΚΕΚΡΙΜΕΝΗ";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "leave_rest_days";
            this.dataGridViewTextBoxColumn9.HeaderText = "ΥΠΟΛΟΙΠΟ ΑΔΕΙΑΣ ΕΤΟΥΣ";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            // 
            // EmpShowAnnLeave
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.emp_annual_leavesDataGridView);
            this.Name = "EmpShowAnnLeave";
            this.Size = new System.Drawing.Size(1335, 769);
            ((System.ComponentModel.ISupportInitialize)(this.emp_annual_leavesDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emp_annual_leavesBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.DataGridView emp_annual_leavesDataGridView;
        private System.Windows.Forms.BindingSource emp_annual_leavesBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
    }
}
