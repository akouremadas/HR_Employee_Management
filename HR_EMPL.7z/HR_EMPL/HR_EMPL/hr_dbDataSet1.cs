﻿namespace HR_EMPL
{


    public partial class hr_dbDataSet1
    {
    }
}
namespace HR_EMPL {
    
    
    public partial class hr_dbDataSet1 {
    }
}
