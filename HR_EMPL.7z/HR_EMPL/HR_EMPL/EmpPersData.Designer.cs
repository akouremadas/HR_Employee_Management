﻿namespace HR_EMPL
{
    partial class EmpPersData
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmpPersData));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.namebox = new System.Windows.Forms.TextBox();
            this.surnamebox = new System.Windows.Forms.TextBox();
            this.agebox = new System.Windows.Forms.TextBox();
            this.afmbox = new System.Windows.Forms.TextBox();
            this.amabox = new System.Windows.Forms.TextBox();
            this.amkabox = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.addressbox = new System.Windows.Forms.TextBox();
            this.phonebox = new System.Windows.Forms.TextBox();
            this.mobilebox = new System.Windows.Forms.TextBox();
            this.emailbox = new System.Windows.Forms.TextBox();
            this.createbtn = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.adtbox = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.genderbox = new System.Windows.Forms.ComboBox();
            this.showAMtxtbx = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "ΟΝΟΜΑ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "ΕΠΩΝΥΜΟ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 88);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(130, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "ΗΜΕΡΟΜΗΝΙΑ ΓΕΝΝΗΣΗΣ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 158);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "ΗΛΙΚΙΑ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 199);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "ΑΦΜ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 272);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "ΑΜΑ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(15, 309);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "ΑΜΚΑ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 352);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(119, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "ΔΙΕΥΘΥΝΣΗ ΚΑΤΟΙΚΙΑΣ";
            // 
            // namebox
            // 
            this.namebox.Location = new System.Drawing.Point(103, 9);
            this.namebox.Name = "namebox";
            this.namebox.Size = new System.Drawing.Size(260, 20);
            this.namebox.TabIndex = 8;
            // 
            // surnamebox
            // 
            this.surnamebox.Location = new System.Drawing.Point(103, 47);
            this.surnamebox.Name = "surnamebox";
            this.surnamebox.Size = new System.Drawing.Size(260, 20);
            this.surnamebox.TabIndex = 9;
            // 
            // agebox
            // 
            this.agebox.Location = new System.Drawing.Point(163, 155);
            this.agebox.Name = "agebox";
            this.agebox.Size = new System.Drawing.Size(200, 20);
            this.agebox.TabIndex = 10;
            // 
            // afmbox
            // 
            this.afmbox.Location = new System.Drawing.Point(163, 196);
            this.afmbox.Name = "afmbox";
            this.afmbox.Size = new System.Drawing.Size(200, 20);
            this.afmbox.TabIndex = 11;
            // 
            // amabox
            // 
            this.amabox.Location = new System.Drawing.Point(163, 269);
            this.amabox.Name = "amabox";
            this.amabox.Size = new System.Drawing.Size(200, 20);
            this.amabox.TabIndex = 12;
            // 
            // amkabox
            // 
            this.amkabox.Location = new System.Drawing.Point(163, 306);
            this.amkabox.Name = "amkabox";
            this.amkabox.Size = new System.Drawing.Size(200, 20);
            this.amkabox.TabIndex = 13;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(163, 82);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 14;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(15, 394);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(116, 13);
            this.label9.TabIndex = 15;
            this.label9.Text = "ΣΤΑΘΕΡΟ ΤΗΛΕΦΩΝΟ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(15, 434);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(104, 13);
            this.label10.TabIndex = 16;
            this.label10.Text = "ΚΙΝΗΤΟ ΤΗΛΕΦΩΝΟ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(15, 472);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(101, 13);
            this.label11.TabIndex = 17;
            this.label11.Text = "ΠΡΟΣΩΠΙΚΟ EMAIL";
            // 
            // addressbox
            // 
            this.addressbox.Location = new System.Drawing.Point(150, 349);
            this.addressbox.Name = "addressbox";
            this.addressbox.Size = new System.Drawing.Size(213, 20);
            this.addressbox.TabIndex = 18;
            // 
            // phonebox
            // 
            this.phonebox.Location = new System.Drawing.Point(150, 391);
            this.phonebox.Name = "phonebox";
            this.phonebox.Size = new System.Drawing.Size(213, 20);
            this.phonebox.TabIndex = 19;
            // 
            // mobilebox
            // 
            this.mobilebox.Location = new System.Drawing.Point(150, 431);
            this.mobilebox.Name = "mobilebox";
            this.mobilebox.Size = new System.Drawing.Size(213, 20);
            this.mobilebox.TabIndex = 20;
            // 
            // emailbox
            // 
            this.emailbox.Location = new System.Drawing.Point(150, 469);
            this.emailbox.Name = "emailbox";
            this.emailbox.Size = new System.Drawing.Size(213, 20);
            this.emailbox.TabIndex = 21;
            // 
            // createbtn
            // 
            this.createbtn.Location = new System.Drawing.Point(18, 524);
            this.createbtn.Name = "createbtn";
            this.createbtn.Size = new System.Drawing.Size(315, 23);
            this.createbtn.TabIndex = 55;
            this.createbtn.Text = "ΔΗΜΙΟΥΡΓΙΑ ΚΑΡΤΕΛΑΣ ΕΡΓΑΖΟΜΕΝΟΥ";
            this.createbtn.UseVisualStyleBackColor = true;
            this.createbtn.Click += new System.EventHandler(this.createbtn_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(97, 107);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 56;
            this.pictureBox1.TabStop = false;
            // 
            // adtbox
            // 
            this.adtbox.Location = new System.Drawing.Point(163, 234);
            this.adtbox.Name = "adtbox";
            this.adtbox.Size = new System.Drawing.Size(200, 20);
            this.adtbox.TabIndex = 58;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(15, 237);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(27, 13);
            this.label12.TabIndex = 57;
            this.label12.Text = "ΑΔΤ";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(15, 122);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(39, 13);
            this.label13.TabIndex = 59;
            this.label13.Text = "ΦΥΛΟ";
            // 
            // genderbox
            // 
            this.genderbox.FormattingEnabled = true;
            this.genderbox.Items.AddRange(new object[] {
            "ΑΡΡΕΝ",
            "ΘΥΛΗ"});
            this.genderbox.Location = new System.Drawing.Point(163, 122);
            this.genderbox.Name = "genderbox";
            this.genderbox.Size = new System.Drawing.Size(200, 21);
            this.genderbox.TabIndex = 60;
            // 
            // showAMtxtbx
            // 
            this.showAMtxtbx.Location = new System.Drawing.Point(150, 612);
            this.showAMtxtbx.Name = "showAMtxtbx";
            this.showAMtxtbx.Size = new System.Drawing.Size(213, 20);
            this.showAMtxtbx.TabIndex = 62;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(11, 615);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(131, 13);
            this.label14.TabIndex = 61;
            this.label14.Text = "ΑΜ ΝΕΟΥ ΕΡΓΑΖΟΜΕΝΟΥ";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.afmbox);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.showAMtxtbx);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.genderbox);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.adtbox);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.namebox);
            this.groupBox1.Controls.Add(this.createbtn);
            this.groupBox1.Controls.Add(this.surnamebox);
            this.groupBox1.Controls.Add(this.emailbox);
            this.groupBox1.Controls.Add(this.agebox);
            this.groupBox1.Controls.Add(this.mobilebox);
            this.groupBox1.Controls.Add(this.amabox);
            this.groupBox1.Controls.Add(this.phonebox);
            this.groupBox1.Controls.Add(this.amkabox);
            this.groupBox1.Controls.Add(this.addressbox);
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Location = new System.Drawing.Point(106, 8);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(381, 639);
            this.groupBox1.TabIndex = 65;
            this.groupBox1.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Location = new System.Drawing.Point(494, 8);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(497, 639);
            this.groupBox2.TabIndex = 66;
            this.groupBox2.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Location = new System.Drawing.Point(997, 8);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(279, 395);
            this.groupBox3.TabIndex = 67;
            this.groupBox3.TabStop = false;
            // 
            // EmpPersData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "EmpPersData";
            this.Size = new System.Drawing.Size(1285, 776);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox namebox;
        private System.Windows.Forms.TextBox surnamebox;
        private System.Windows.Forms.TextBox agebox;
        private System.Windows.Forms.TextBox afmbox;
        private System.Windows.Forms.TextBox amabox;
        private System.Windows.Forms.TextBox amkabox;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox addressbox;
        private System.Windows.Forms.TextBox phonebox;
        private System.Windows.Forms.TextBox mobilebox;
        private System.Windows.Forms.TextBox emailbox;
        private System.Windows.Forms.Button createbtn;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox adtbox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox genderbox;
        private System.Windows.Forms.TextBox showAMtxtbx;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
    }
}
