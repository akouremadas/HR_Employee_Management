﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR_EMPL
{
    public partial class AdminUser : UserControl
    {
        //singleton user control
        private static AdminUser _instance;
        public static AdminUser Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new AdminUser();
                }
                return _instance;
            }
        }
        public AdminUser()
        {
            InitializeComponent();
        }

        private void createusernamebtn_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(EmpCreateUserPass.Instance))
            {
                panel1.Controls.Add(EmpCreateUserPass.Instance);
                EmpCreateUserPass.Instance.Dock = DockStyle.Fill;
                EmpCreateUserPass.Instance.BringToFront();
            }

            else
            {
                EmpCreateUserPass.Instance.BringToFront();
            }
        }

        private void emplcreatebtn_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(EmpPersData.Instance))
            {
                panel1.Controls.Add(EmpPersData.Instance);
                EmpPersData.Instance.Dock = DockStyle.Fill;
                EmpPersData.Instance.BringToFront();
            }

            else
            {
                EmpPersData.Instance.BringToFront();
            }
        }

        private void empltermbtn_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(EmpContrTerm.Instance))
            {
                panel1.Controls.Add(EmpContrTerm.Instance);
                EmpContrTerm.Instance.Dock = DockStyle.Fill;
                EmpContrTerm.Instance.BringToFront();
            }

            else
            {
                EmpContrTerm.Instance.BringToFront();
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(EmpChangeCred.Instance))
            {
                panel1.Controls.Add(EmpChangeCred.Instance);
                EmpChangeCred.Instance.Dock = DockStyle.Fill;
                EmpChangeCred.Instance.BringToFront();
            }

            else
            {
                EmpChangeCred.Instance.BringToFront();
            }
        }

    }
}
