﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR_EMPL
{
    public partial class HRUser : UserControl
    {
        //singleton user control
        private static HRUser _instance;
        public static HRUser Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new HRUser();
                }
                return _instance;
            }
        }
        public HRUser()
        {
            InitializeComponent();
        }

        private void emplcreatebtn_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(EmpPersData.Instance))
            {
                panel1.Controls.Add(EmpPersData.Instance);
                EmpPersData.Instance.Dock = DockStyle.Fill;
                EmpPersData.Instance.BringToFront();
            }

            else
            {
                EmpPersData.Instance.BringToFront();
            }
        }

        private void empltermbtn_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(EmpContrTerm.Instance))
            {
                panel1.Controls.Add(EmpContrTerm.Instance);
                EmpContrTerm.Instance.Dock = DockStyle.Fill;
                EmpContrTerm.Instance.BringToFront();
            }

            else
            {
                EmpContrTerm.Instance.BringToFront();
            }
        }

        private void annualleaveapprovalbtn_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(EmpAnnualLeaveApproval.Instance))
            {
                panel1.Controls.Add(EmpAnnualLeaveApproval.Instance);
                EmpAnnualLeaveApproval.Instance.Dock = DockStyle.Fill;
                EmpAnnualLeaveApproval.Instance.BringToFront();
            }

            else
            {
                EmpAnnualLeaveApproval.Instance.BringToFront();
            }
        }
    }
}
