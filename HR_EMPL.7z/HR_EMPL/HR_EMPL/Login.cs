﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR_EMPL
{
    public partial class Login : Form
    {
        db db1 = new db();
        public static string role;
        public static int id;

        public Login()
        {
            InitializeComponent();
        }

        private void usernametxtbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            //checks if enter key is pressed
            if (e.KeyChar == (char)13)
            {
                passtxtbox.Focus();
            }

        }

        private void passtxtbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            //checks if enter key is pressed
            if (e.KeyChar == (char)13)
            {
                enterbtn.Focus();
            }

        }

        private void enterbtn_Click(object sender, EventArgs e)
        {
           

            if (string.IsNullOrEmpty(usernametxtbox.Text))
            {
                MessageBox.Show("Παρακαλώ εισάγετε το όνομα χρήστη.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                usernametxtbox.Focus();
                return;
            }

            if (string.IsNullOrEmpty(passtxtbox.Text))
            {
                MessageBox.Show("Παρακαλώ εισάγετε τον κωδικό χρήστη.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                passtxtbox.Focus();
                return;
            }


            db1.db_open();

            db1.db_user_auth(usernametxtbox.Text, passtxtbox.Text);

            role = db1.user_retrieve_role(usernametxtbox.Text);

            id = db1.user_retrieve_id(usernametxtbox.Text);

            db1.db_close();

            this.Close();

            User_Interface user = new User_Interface();
            user.Show();

        }

        private void cancelbtn_Click(object sender, EventArgs e)
        {
            this.Close();

            Form1 form = new Form1();
            form.Show();
        }
    }
}
