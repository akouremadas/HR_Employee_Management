﻿namespace HR_EMPL
{


    partial class hr_dbDataSet
    {
    }
}

namespace HR_EMPL.hr_dbDataSetTableAdapters {
    
    
    public partial class emp_annual_leavesTableAdapter {
    }
}
