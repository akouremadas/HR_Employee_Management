﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace HR_EMPL
{
    public partial class EmpShowAnnLeave : UserControl
    {

        OleDbConnection conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0; Data Source=hr_db.accdb");

        //singleton user control
        private static EmpShowAnnLeave _instance;
        public static EmpShowAnnLeave Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new EmpShowAnnLeave();
                }
                return _instance;
            }
        }
        public EmpShowAnnLeave()
        {
            InitializeComponent();
            int id = Login.id;
            show_user_annual_leaves(id);
        }

        public void show_user_annual_leaves(int id)//ok
        {
            conn.Open();
            String myquery = "SELECT emp_id,leave_start, leave_end, leave_wdays,leave_appr,	leave_rest_days FROM emp_annual_leaves WHERE emp_id = " + id + "";
            OleDbCommand cmd = new OleDbCommand(myquery, conn);

            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);

            da.Fill(dt);

            emp_annual_leavesDataGridView.DataSource = dt;

            conn.Close();
        }



    }
}
