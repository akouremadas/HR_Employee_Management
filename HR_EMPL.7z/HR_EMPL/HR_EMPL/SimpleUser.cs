﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR_EMPL
{
    public partial class SimpleUser : UserControl
    {
        //singleton user control
        private static SimpleUser _instance;
        public static SimpleUser Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new SimpleUser();
                }
                return _instance;
            }
        }
        public SimpleUser()
        {
            InitializeComponent();
        }

        private void personaldatabtn_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(EmpShowPersData.Instance))
            {
                panel1.Controls.Add(EmpShowPersData.Instance);
                EmpShowPersData.Instance.Dock = DockStyle.Fill;
                EmpShowPersData.Instance.BringToFront();
            }

            else
            {
                EmpShowPersData.Instance.BringToFront();
            }

            
        }

        private void financialdatabtn_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(EmpShowFinData.Instance))
            { 
                panel1.Controls.Add(EmpShowFinData.Instance);
            EmpShowFinData.Instance.Dock = DockStyle.Fill;
            EmpShowFinData.Instance.BringToFront();
            }

            else
            {
                EmpShowFinData.Instance.BringToFront();
            }
        }

        private void annualleavebtn_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(EmpShowAnnLeave.Instance))
            {
                panel1.Controls.Add(EmpShowAnnLeave.Instance);
                EmpShowAnnLeave.Instance.Dock = DockStyle.Fill;
                EmpShowAnnLeave.Instance.BringToFront();
            }

            else
            {
                EmpShowAnnLeave.Instance.BringToFront();
            }
        }

        private void sendemailbtn_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(EmpSendEmail.Instance))
            {
                panel1.Controls.Add(EmpSendEmail.Instance);
                EmpSendEmail.Instance.Dock = DockStyle.Fill;
                EmpSendEmail.Instance.BringToFront();
            }

            else
            {
                EmpSendEmail.Instance.BringToFront();
            }
        }

        private void submitannualleavebtn_Click(object sender, EventArgs e)
        {
            if (!panel1.Controls.Contains(EmpRegAnnLeave.Instance))
            {
                panel1.Controls.Add(EmpRegAnnLeave.Instance);
                EmpRegAnnLeave.Instance.Dock = DockStyle.Fill;
                EmpRegAnnLeave.Instance.BringToFront();
            }

            else
            {
                EmpRegAnnLeave.Instance.BringToFront();
            }
        }
    }
}
