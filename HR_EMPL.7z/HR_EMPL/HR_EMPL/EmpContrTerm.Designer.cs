﻿namespace HR_EMPL
{
    partial class EmpContrTerm
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.termpicker = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.idbox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.updatebtn = new System.Windows.Forms.Button();
            this.termcombobox = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 135);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(140, 13);
            this.label3.TabIndex = 52;
            this.label3.Text = "ΤΥΠΟΣ ΛΗΞΗΣ ΣΥΜΒΑΣΗΣ";
            // 
            // termpicker
            // 
            this.termpicker.Location = new System.Drawing.Point(212, 89);
            this.termpicker.Name = "termpicker";
            this.termpicker.Size = new System.Drawing.Size(200, 20);
            this.termpicker.TabIndex = 51;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(24, 95);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(171, 13);
            this.label9.TabIndex = 50;
            this.label9.Text = "ΗΜΕΡΟΜΗΝΙΑ ΛΗΞΗΣ ΣΥΜΒΑΣΗΣ";
            // 
            // idbox
            // 
            this.idbox.Location = new System.Drawing.Point(212, 35);
            this.idbox.Name = "idbox";
            this.idbox.Size = new System.Drawing.Size(200, 20);
            this.idbox.TabIndex = 55;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 13);
            this.label1.TabIndex = 54;
            this.label1.Text = "ΑΜ ΕΡΓΑΖΟΜΕΝΟΥ";
            // 
            // updatebtn
            // 
            this.updatebtn.Location = new System.Drawing.Point(99, 238);
            this.updatebtn.Name = "updatebtn";
            this.updatebtn.Size = new System.Drawing.Size(227, 23);
            this.updatebtn.TabIndex = 56;
            this.updatebtn.Text = "ΤΕΡΜΑΤΙΣΜΟΣ ΣΥΜΒΑΣΗΣ";
            this.updatebtn.UseVisualStyleBackColor = true;
            this.updatebtn.Click += new System.EventHandler(this.updatebtn_Click);
            // 
            // termcombobox
            // 
            this.termcombobox.FormattingEnabled = true;
            this.termcombobox.Items.AddRange(new object[] {
            "ΑΠΟΛΥΣΗ",
            "ΠΑΡΑΙΤΗΣΗ",
            "ΜΗ ΑΝΑΝΕΩΣΗ"});
            this.termcombobox.Location = new System.Drawing.Point(212, 135);
            this.termcombobox.Name = "termcombobox";
            this.termcombobox.Size = new System.Drawing.Size(200, 21);
            this.termcombobox.TabIndex = 57;
            // 
            // EmpContrTerm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.termcombobox);
            this.Controls.Add(this.updatebtn);
            this.Controls.Add(this.idbox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.termpicker);
            this.Controls.Add(this.label9);
            this.Name = "EmpContrTerm";
            this.Size = new System.Drawing.Size(454, 326);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker termpicker;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox idbox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button updatebtn;
        private System.Windows.Forms.ComboBox termcombobox;
    }
}
