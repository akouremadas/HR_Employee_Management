﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR_EMPL
{
    public partial class EmpChangeCred : UserControl
    {
        db db1 = new db();

        private static EmpChangeCred _instance;
        public static EmpChangeCred Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new EmpChangeCred();
                }
                return _instance;
            }
        }
        public EmpChangeCred()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            db1.db_open();
            db1.find_user(userbox.Text);
            db1.db_close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            db1.db_open();
            db1.change_credentials(userbox.Text, passbox.Text, rolecombo.Text );
            db1.db_close();
        }
    }
}
