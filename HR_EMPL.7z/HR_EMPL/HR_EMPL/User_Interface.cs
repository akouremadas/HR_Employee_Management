﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR_EMPL
{
    public partial class User_Interface : Form
    {
        public User_Interface()
        {
            InitializeComponent();

            if (Login.role == "ADMIN")
            {
                if (!panel1.Controls.Contains(AdminUser.Instance))
                {
                    panel1.Controls.Add(AdminUser.Instance);
                    AdminUser.Instance.Dock = DockStyle.Fill;
                    AdminUser.Instance.BringToFront();
                }

                else
                {
                    AdminUser.Instance.BringToFront();
                }
            }

            else if (Login.role == "HR")
            {
                if (!panel1.Controls.Contains(HRUser.Instance))
                {
                    panel1.Controls.Add(HRUser.Instance);
                    HRUser.Instance.Dock = DockStyle.Fill;
                    HRUser.Instance.BringToFront();
                }

                else
                {
                    AdminUser.Instance.BringToFront();
                }
            }

            else
            {
                if (!panel1.Controls.Contains(SimpleUser.Instance))
                {
                    panel1.Controls.Add(SimpleUser.Instance);
                    SimpleUser.Instance.Dock = DockStyle.Fill;
                    SimpleUser.Instance.BringToFront();
                }

                else
                {
                    SimpleUser.Instance.BringToFront();
                }
            }

            

        }

        private void εΞΟΔΟΣToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void lOGOUTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }

        private void logoutbtn_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
            
        }

        private void exitbtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void aBOUTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox1 ab = new AboutBox1();

            ab.ShowDialog();
        }

        
    }

}
