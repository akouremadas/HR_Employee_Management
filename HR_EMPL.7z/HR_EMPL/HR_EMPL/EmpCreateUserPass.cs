﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR_EMPL
{
    public partial class EmpCreateUserPass : UserControl
    {
        db db2 = new db();
        int emp_id;
        //singleton user control
        private static EmpPersData _instance;
        
        public static EmpPersData Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new EmpPersData();
                }
                return _instance;
            }
        }
        public EmpCreateUserPass()
        {
            InitializeComponent();
            idbox.Text = EmpPersData.id.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                emp_id = Int32.Parse(idbox.Text);
            }
            catch (FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }

            db2.db_open();

            db2.create_credentials(emp_id, userbox.Text, passbox.Text, rolecombo.Text);

            db2.db_close();
        }
    }
}
