﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR_EMPL
{
    public partial class EmpPersData : UserControl
    {
        DateTime datenow = DateTime.Now;
        DateTime dateofbirth;
        public static int id;
        string dateofbirth2;
        db db1 = new db();


        //singleton user control
        private static EmpPersData _instance;
        private int age;
        public static int idnew;

        int empid;

        public static EmpPersData Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new EmpPersData();
                }
                return _instance;
            }
        }
        public EmpPersData()
        {
            InitializeComponent();
        }

        public void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            dateofbirth = dateTimePicker1.Value;
           string dateofbirth2 = dateofbirth.ToString();
            age = datenow.Year - dateofbirth.Year;
            agebox.Text = age.ToString();
        }

        private void createbtn_Click(object sender, EventArgs e)
        {

            db1.db_open();

            try
            {
                age = Int32.Parse(agebox.Text);
            }
            catch (FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }

            db1.create_user(namebox.Text, surnamebox.Text, dateofbirth2, genderbox.Text, age , afmbox.Text, adtbox.Text, amabox.Text, amkabox.Text, addressbox.Text, phonebox.Text, mobilebox.Text, emailbox.Text);

            id = db1.show_emp_id(afmbox.Text);
            showAMtxtbx.Text = db1.show_emp_id(afmbox.Text).ToString();


            if (!groupBox3.Controls.Contains(EmpCreateUserPass.Instance))
            {
                groupBox3.Controls.Add(EmpCreateUserPass.Instance);
                EmpCreateUserPass.Instance.Dock = DockStyle.Fill;
                EmpCreateUserPass.Instance.BringToFront();
            }

            else
            {
                EmpCreateUserPass.Instance.BringToFront();
            }

            if (!groupBox2.Controls.Contains(EmpFinData.Instance))
            {
                groupBox2.Controls.Add(EmpFinData.Instance);
                EmpFinData.Instance.Dock = DockStyle.Fill;
                EmpFinData.Instance.BringToFront();
            }

            else
            {
                EmpFinData.Instance.BringToFront();
            }
        }
    }
}
